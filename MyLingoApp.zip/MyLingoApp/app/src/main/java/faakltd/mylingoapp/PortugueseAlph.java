package faakltd.mylingoapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import static faakltd.mylingoapp.R.id.Portuguese;
import static faakltd.mylingoapp.R.id.textView5;
import static faakltd.mylingoapp.R.id.welcome7;



public class PortugueseAlph extends ActionBarActivity {

    TextView welcome;
    TextView phrases;
    Button next1;
    Button logout;
    Button play;
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portuguese_alph);

        next1 = (Button) findViewById(R.id.commonNext);
        logout = (Button) findViewById(R.id.logout_p);
        play = (Button)findViewById(R.id.playSound);







        Bundle extras = getIntent().getExtras();
        final String welcomeText = extras.getString("username");

        welcome = (TextView) findViewById(welcome7);
        phrases = (TextView) findViewById(textView5);

        welcome.setText(""+welcomeText);


        logout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                Intent i = new Intent(PortugueseAlph.this, MainActivity.class);

                startActivity(i);

            }
        });



        getData();
    }



    public void getData() {


        String result = "";
        InputStream isr = null;


        InputStream is = null;
        //add paramaters using an arryList key value


        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(
                    "http://lingo.hostei.com/getalpha_port.php");

            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            isr = entity.getContent();
            Log.d("HTTP", "HTTP: OK");

        } catch (Exception e) {
            Log.e("HTTP", "Error in http connection " + e.toString());
        }

        // convert response to string
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    isr, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            //reads line for line
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            isr.close();

            result = sb.toString();
            //phrases.setText("" + result);

        } catch (Exception e) {
            Log.e("log_tag", "Error  converting result " + e.toString());
        }


        //parse json data



        final String finalResult = result;
        next1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                try {
                    String s = "";
                    JSONArray jArray = new JSONArray(finalResult);


                    JSONObject json = jArray.getJSONObject(count);
                    s = s +json.getString("letter");



                    for (int i = 0; i < jArray.length(); i++) {

                        String[] mp3SoundByteArray = new String[5];


                        mp3SoundByteArray[i] = json.getString("letter");

                   System.out.println("here is "+mp3SoundByteArray[i].toString());

                    }

                    phrases.setText("" + s);

                    count++;
                    if (count >= jArray.length()) {
                        count = 0;

                    }

                    play.setOnClickListener(new View.OnClickListener() {


                        @Override
                        public void onClick(View v) {

                            MediaPlayer mediaPlayer = MediaPlayer.create(PortugueseAlph.this, R.raw.port0);
                            mediaPlayer.start();



                        }
                    });

                } catch (Exception e) {
                    // TODO: handle exception
                    Log.e("log_tag", "Error Parsing Data " + e.toString());
                }

            }

        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_portuguese_alph, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
